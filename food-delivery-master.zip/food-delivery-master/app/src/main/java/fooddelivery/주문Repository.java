package fooddelivery;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface 주문Repository extends PagingAndSortingRepository<Order, Long>{


}